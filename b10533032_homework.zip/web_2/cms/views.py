from django.shortcuts import render_to_response
from django.shortcuts import render
# Create your views here.
from .models import Restaurant, Food, Student

def index(request):
	students = Student.objects.all()
	return render_to_response('cms/index.html',locals())

def school(request):
	return render(request,'cms/School.html')

def life(request):
	return render(request,'cms/life.html')
