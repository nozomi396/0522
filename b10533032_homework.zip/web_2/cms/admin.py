from django.contrib import admin
from .models import Restaurant,Food,Student
# Register your models here.

class RestaurantAdmin(admin.ModelAdmin):
	list_display = ('name', 'phone_number', 'address')

class FoodAdmin(admin.ModelAdmin):
	list_display = ('name', 'price')

class StudentAdmin(admin.ModelAdmin):
	list_display = ('name', 'school', 'age', 'fav_food')

admin.site.register(Food)
admin.site.register(Restaurant)
admin.site.register(Student)
